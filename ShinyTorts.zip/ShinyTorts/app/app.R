# app launching code, e.g.:
shiny::runApp("./app/shiny/", launch.browser=TRUE)
