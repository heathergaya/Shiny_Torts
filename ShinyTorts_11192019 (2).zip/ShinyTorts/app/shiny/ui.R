library(shiny)
library(shinyjs)


ui <<- fixedPage(
  #js <- ,
  useShinyjs(),
  tags$head(
    tags$script(HTML("
                     $(document).ready(function() {
                     $('#runmodel').on('click', function(){
                     var date = new Date().toLocaleString();
                     $('#busy').html('Results will show up below (scroll down). Model started: ' + date);
                     });
                     $('#model.ran').on('shiny:value', function(event) {
                     $('#busy').html('');
                     });
                     });
                     $(document).ready(function() {
                     $('#extendmodel').on('click', function(){
                     var date = new Date().toLocaleString();
                     $('#busy2').html('Results will show up below (scroll down). Model started: ' + date);
                     });
                     $('#model.extended').on('shiny:value', function(event) {
                     $('#busy2').html('');
                     });
                     });
                     ")),
    tags$style(type = 'text/css', '#title{font-size: 48px; font-family: calibri light; 
               background-color: rgba(255,255,255,0.40); color: blue; border-style: none;}')
    ),
  
  fixedRow(
    column(width =10, textOutput("title"), offset = 2)),
  
  fixedRow(
    column(radioButtons("DetectionButton", 
                        "Is detection on the transect perfect? i.e. is g(0) = 1?", 
                        c("Likely imperfect", "Perfect Detection!")), width = 4),
    
    column(width = 4, radioButtons("ELTDSButton", 
                                   "Was data collected with standard LTDS (conventional survey) or Enhanced LTDS (double sampling)?", 
                                   c("Conventional LTDS", "Enhanced LTDS"))),
    column(width =4, radioButtons("VegButton", 
                                  "Does the data include vegetation measurements (or a similar individual covariate)?", 
                                  c("Yes", "No")))),
  
  fixedRow(
    column(width = 4, fileInput("file", h3("Burrow Data (.csv)"), 
                                accept=c('text/csv', 'text/comma-separated-values,text/plain'))),
    column(tableOutput("file"), width = 8)),
  
  fixedRow(
    column(fileInput("file2", h3("Transect Data (.csv)"),
                     accept=c('text/csv', 'text/comma-separated-values,text/plain')), width = 4),
    column(tableOutput("file2"), width = 8)),
  
  fixedRow(
    column(fileInput("file3", h3("Veg Data (.csv)"),
                     accept=c('text/csv', 'text/comma-separated-values,text/plain')), width = 4),
    column(tableOutput("file3"), width = 8)),
  
  fixedRow(
    column(sliderInput("slider", label = "Estimated Detection on the Line for 5 cm Burrows",
                       min = 0, max = 1, value = c(.4, .6)), width = 4),
    column(textOutput("min_max"), width = 2),
    
    column(sliderInput("timeslider", label = "Maximum Time for Model Run",
                       min = 0, max = 10, value = 4, step = .25), width =4),
    column(textOutput("slidermax"), width = 2)),
  fixedRow(
    
    column(5, 
           actionButton("prepmodel", "Load the Model")), 
    textOutput("model.prepped")
  ),
  
  fixedRow(
    column(5, 
           actionButton("runmodel", "Run the Model")),
    tags$p(id = "busy")
  ),
  
  fixedRow(
    column(5,
           actionButton("extendmodel", "Extend the Model")),
    tags$p(id = "busy2")
  ),
  
  
  fixedRow(
    column(5, align = "center", tableOutput("model.ran"))),
  
  fixedRow(
    column(5, align = "center", tableOutput("model.extended")))
  )


# Run the app ----
