






# Define server logic ----
server <- function(input, output, session) {
    session$onSessionEnded(function() {
      stopApp()
    })
  
  output$min_max <- renderText({ 
    paste("You have chosen a range that goes from",
          input$slider[1], "to", input$slider[2])
  })
  output$slidermax <- renderText({ 
    paste("The model will run for an (estimated) maximum of",
          input$timeslider, "hours")
  })
  output$file <- renderTable({
    head.Burrows()
  })
  
  
  output$file2 <- renderTable({
    head.Trans()
  })
  
  output$file3 <- renderTable({
    head.Veg()
  })
  
  observeEvent(input$VegButton, {
    if(input$VegButton == "No") {
      toggle(id = "file3")
    }})
  
  observeEvent(input$DetectionButton, {
    if(input$DetectionButton == "Perfect Detection!") {
      toggle(id = "slider")
      toggle(id = "min_max")
    }})
  
  observeEvent(input$file3, {
    inFile3 <- isolate({input$file3})
    Veg <<- read.csv(inFile3$datapath)
  })
  
  observeEvent(input$prepmodel, {
    inFile <- isolate({input$file })
    Burrows <<- read.csv(inFile$datapath)
    inFile2 <- isolate({input$file2 })
    Trans <<- read.csv(inFile2$datapath)
    Freq <<- input$ELTDSButton
    
    one <<- switch(input$DetectionButton, "Perfect Detection!" = 1, "Likely imperfect" = 2)
    two <<- switch(input$ELTDSButton, "Conventional LTDS" = 1, "Enhanced LTDS" = 2)
    three <<- switch(input$VegButton, "Yes" = 1, "No" = 2)
    
    chosenmodel <<- paste(c(one, two, three), collapse = "")
    ### choose which model is being run 
    selected.model <<- ifelse(chosenmodel == "112", "modelstring.PC",
                              ifelse(chosenmodel == "111", "modelstring.PCV",
                                     ifelse(chosenmodel == "122", "modelstring.PE",
                                            ifelse(chosenmodel == "121", "modelstring.PEV",
                                                   ifelse(chosenmodel == "212", "modelstring.IC",
                                                          ifelse(chosenmodel == "211", "modelstring.ICV",
                                                                 ifelse(chosenmodel == "222", "modelstring.IE",
                                                                        "modelstring.IEV")))))))
    
    p.min <<- input$slider[1]
    p.max <<- input$slider[2]
    maxusrtime <<- paste(input$timeslider, "h")
    source('Bias_Adjusted_Model_412019.R')
    output$model.prepped <- renderText({
      paste(c("Model is Loaded! You have chosen this model: ", selected.model))
    })
  })
  
  observeEvent(input$runmodel, {
    maxusrtime <<- paste(input$timeslider, "h")
    Run.me(Burrows)
  })
  
  observeEvent(input$runmodel, {
    output$model.ran <- renderTable({
      summary(Foo)[,c(1:5,11)]
    }, rownames = TRUE)})
  
  observeEvent(input$extendmodel, {
    Extend.me(Burrows)
    output$model.extended <- renderTable({
      summary(Foo)[,c(1:5,11)]
    }, rownames = TRUE)})
  
  
  head.Burrows <- reactive({
    infile <- input$file
    if (is.null(infile)) {
      # User has not uploaded a file yet
      return(NULL)
    }
    head(read.csv(infile$datapath, header = T), n =2)
    
  })
  
  head.Trans <- reactive({
    infile2 <- input$file2
    if (is.null(infile2)) {
      # User has not uploaded a file yet
      return(NULL)
    }
    head(read.csv(infile2$datapath, header = T), n= 2)
  })
  
  head.Veg <- reactive({
    infile3 <- input$file3
    if (is.null(infile3)) {
      # User has not uploaded a file yet
      return(NULL)
    }
    head(read.csv(infile3$datapath, header = T), n= 2)
  })
  
  output$title <- renderText({"Bayesian LTDS Made 'Simple'"})
  
}

#shinyApp(ui = ui, server = server)