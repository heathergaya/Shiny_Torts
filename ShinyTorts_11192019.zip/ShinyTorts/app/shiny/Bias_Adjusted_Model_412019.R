
##check to make sure all the needed packages are installed and install them if need be ####
list.of.packages <- c('rjags', 'runjags', "lme4", "Rcpp", "geometry", "coda", "grDevices", "rgl")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages, repos = "http://cran.us.r-project.org")
lapply(list.of.packages,function(x){library(x,character.only=TRUE)})


#### Models ##########
modelstring.IC = "
model
{
  for (i in 1:(nind +nz)) {
  w[i] ~ dbern(psi)					#augmentation 
  x[i] ~ dunif(0,Bx)					#distance from line; Bx = max(distances) 
  
  z[i] ~ dgamma(a[i],c.beta[i])T(4,65)		#covariate                
  a[i] <- shape[clust[i]]		## a depends on which cluster the size comes from
  c.beta[i] <- betaClust[clust[i]]	#precision is allowed to vary between clusters
  clust[i] ~ dcat( pClust[1:Nclust] )	## clusters are defined as categories, assuming Nclust clusters
  
  sigma[i] <- exp(sigma.int+sigma.beta*z[i])  #sigma of detection
  logp[i] <- -((x[i]*x[i])/(2*sigma[i]*sigma[i]))	#This is the normal distribution with an adjustment for covs
  p[i] <- exp(logp[i])*xi[i]
  xi[i] <- ifelse(z[i] < b.point, m*z[i]+intercept, 1) #if less than b.point, probability is linear; if larger than b.point, perfect detection on line
  
  mu[i] <- w[i]*p[i] 					# probabilty of seeing it for all the ones we DID see (where w[i] = 1)
  
  y[i] ~ dbern(mu[i])         #found vs. missed
  
  o[i]~ dbin(o2[i], 1)        #occupancy
  logit(o2[i]) <- o.int + z.beta*z[i]						
  }
  
  
  p.online ~ dunif(pmin, pmax)		#estimated detection on line for 4 cm burrows
  b.point ~ dunif(15,22)
  m <- (1-p.online)/(b.point-4) 	#slope for detection on the line for smaller burrows		
  intercept <- p.online-(4*m)	## finding intercept via the detection of the 4 cm burrow 
  
  
  sigma.int~ dnorm(0,s.int.tau)T(0,)
  s.int.tau <- 1/(s.int.sd*s.int.sd)
  s.int.sd ~ dunif(.00001,5)	
  sigma.beta~ dnorm(0,s.beta.tau)T(0,)
  s.beta.tau <- 1/(s.beta.sd*s.beta.sd)
  s.beta.sd ~ dunif(.00001,5)
  o.int~ dnorm(0,o.int.tau)
  o.int.tau <- 1/(o.int.sd*o.int.sd)
  o.int.sd ~ dunif(.00001,5)		
  z.beta~ dnorm(0,z.beta.tau)
  z.beta.tau <- 1/(z.beta.sd*z.beta.sd)
  z.beta.sd ~ dunif(.00001,5)	
  
  for (clustIdx in 1: Nclust) {
  shape[clustIdx] ~ dunif(1,80)
  betaClust[clustIdx] ~ dunif(0.2,2)
  }
  
  pClust[1:Nclust] ~ ddirch(onesRepNclust) # probability of each cluster = the probability of that category in the ddirch distribution
  
  
  psi~ dunif(0,1)			#exists or not		
  
  
  juvi1 <- (sum(z*w <= 13) - sum(z*w <1))/N
  juvi2 <- (sum(z*w < 21) - sum(z*w <13))/N
  juvi3 <- sum(z*w >= 21)/N
  
  Occ <- sum(o)/(nind+nz)
  N <- sum(w)		
  D <- N/(2*L*Bx)			#burrow density
  Nt <- N*Occ 			 
  Dt <- Nt/(2*L*Bx)			#tort density
  small <- (sum(z*w*o < 13) - sum(z*w*o <1))/Nt
  big <- sum(z*w*o >= 22)/Nt
  med <- (sum(z*w*o < 22) - sum(z*w*o <13))/Nt
  
  
  
}
"

modelstring.PC = "
model
{
  for (i in 1:(nind +nz)) {
  w[i] ~ dbern(psi)					#augmentation 
  x[i] ~ dunif(0,Bx)					#distance from line; Bx = max(distances) 
  
  z[i] ~ dgamma(a[i],c.beta[i])T(4,65)		#covariate                
  a[i] <- shape[clust[i]]		## a depends on which cluster the size comes from
  c.beta[i] <- betaClust[clust[i]]	#precision is allowed to vary between clusters
  clust[i] ~ dcat( pClust[1:Nclust] )	## clusters are defined as categories, assuming Nclust clusters
  
  sigma[i] <- exp(sigma.int+sigma.beta*z[i])  #sigma of detection
  logp[i] <- -((x[i]*x[i])/(2*sigma[i]*sigma[i]))	#This is the normal distribution with an adjustment for covs
  p[i] <- exp(logp[i])

  mu[i] <- w[i]*p[i] 					# probabilty of seeing it for all the ones we DID see (where w[i] = 1)
  
  y[i] ~ dbern(mu[i])         #found vs. missed
  
  o[i]~ dbin(o2[i], 1)        #occupancy
  logit(o2[i]) <- o.int + z.beta*z[i]						
  }
  
  
  p.online <-1		#estimated detection on line for 4 cm burrows
  b.point <- 4
  
  sigma.int~ dnorm(0,s.int.tau)T(0,)
  s.int.tau <- 1/(s.int.sd*s.int.sd)
  s.int.sd ~ dunif(.00001,5)	
  sigma.beta~ dnorm(0,s.beta.tau)T(0,)
  s.beta.tau <- 1/(s.beta.sd*s.beta.sd)
  s.beta.sd ~ dunif(.00001,5)
  o.int~ dnorm(0,o.int.tau)
  o.int.tau <- 1/(o.int.sd*o.int.sd)
  o.int.sd ~ dunif(.00001,5)		
  z.beta~ dnorm(0,z.beta.tau)
  z.beta.tau <- 1/(z.beta.sd*z.beta.sd)
  z.beta.sd ~ dunif(.00001,5)	
  
  for (clustIdx in 1: Nclust) {
  shape[clustIdx] ~ dunif(1,80)
  betaClust[clustIdx] ~ dunif(0.2,2)
  }
  
  pClust[1:Nclust] ~ ddirch(onesRepNclust) # probability of each cluster = the probability of that category in the ddirch distribution
  
  psi~ dunif(0,1)			#exists or not		
  
  
 juvi1 <- (sum(z*w <= 13) - sum(z*w <1))/N
  juvi2 <- (sum(z*w < 21) - sum(z*w <13))/N
  juvi3 <- sum(z*w >= 21)/N
  
  Occ <- sum(o)/(nind+nz)
  N <- sum(w)		
  D <- N/(2*L*Bx)			#burrow density
  Nt <- N*Occ 			 
  Dt <- Nt/(2*L*Bx)			#tort density
  small <- (sum(z*w*o < 13) - sum(z*w*o <1))/Nt
  big <- sum(z*w*o >= 22)/Nt
  med <- (sum(z*w*o < 22) - sum(z*w*o <13))/Nt
}
"

modelstring.ICV = "
model
{
  for (i in 1:(nind +nz)) {
  w[i] ~ dbern(psi)					#augmentation 
  x[i] ~ dunif(0,Bx)					#distance from line; Bx = max(distances) 
  
  z[i] ~ dgamma(a[i],c.beta[i])T(4,65)		#covariate                
  a[i] <- shape[clust[i]]		## a depends on which cluster the size comes from
  c.beta[i] <- betaClust[clust[i]]	#precision is allowed to vary between clusters
  clust[i] ~ dcat( pClust[1:Nclust] )	## clusters are defined as categories, assuming Nclust clusters
  
  v[i] ~ dbeta(d,e)T(.05,.95)				## vegetation is unknown so beta prior
  sigma[i] <- exp(sigma.int+sigma.beta*z[i]+sigma.gamma*v[i])  #sigma of detection
  logp[i] <- -((x[i]*x[i])/(2*sigma[i]*sigma[i]))	#This is the normal distribution with an adjustment for covs
  p[i] <- exp(logp[i])*xi[i]
  xi[i] <- ifelse(z[i] < b.point, m*z[i]+intercept, 1) #if less than b.point, probability is linear; if larger than b.point, perfect detection on line
  
  mu[i] <- w[i]*p[i] 					# probabilty of seeing it for all the ones we DID see (where w[i] = 1)
  
  y[i] ~ dbern(mu[i])         #found vs. missed
  
  o[i]~ dbin(o2[i], 1)        #occupancy
  logit(o2[i]) <- o.int + z.beta*z[i]						
  }
  
  for (q in 1:q) {
    v2[q] ~ dbeta (d,e)T(.05,.95)		# all veg measurements at the site
  }
  
  p.online ~ dunif(pmin, pmax)		#estimated detection on line for 4 cm burrows
  b.point ~ dunif(15,22)
  m <- (1-p.online)/(b.point-4) 	#slope for detection on the line for smaller burrows		
  intercept <- p.online-(4*m)	## finding intercept via the detection of the 4 cm burrow 
  
  
  sigma.int~ dnorm(0,s.int.tau)T(0,)
  s.int.tau <- 1/(s.int.sd*s.int.sd)
  s.int.sd ~ dunif(.00001,5)	
  sigma.beta~ dnorm(0,s.beta.tau)T(0,)
  s.beta.tau <- 1/(s.beta.sd*s.beta.sd)
  s.beta.sd ~ dunif(.00001,5)
  o.int~ dnorm(0,o.int.tau)
  o.int.tau <- 1/(o.int.sd*o.int.sd)
  o.int.sd ~ dunif(.00001,5)		
  z.beta~ dnorm(0,z.beta.tau)
  z.beta.tau <- 1/(z.beta.sd*z.beta.sd)
  z.beta.sd ~ dunif(.00001,5)	
  sigma.gamma~ dnorm(0,s.gamma.tau)T(,0)
  s.gamma.tau <- 1/(s.gamma.sd*s.gamma.sd)
  s.gamma.sd ~ dunif(.00001,5)
  
  d~dunif(.1,40)
  e~dunif(.1,40)
  
  for (clustIdx in 1: Nclust) {
  shape[clustIdx] ~ dunif(1,80)
  betaClust[clustIdx] ~ dunif(0.2,2)
  }
  
  pClust[1:Nclust] ~ ddirch(onesRepNclust) # probability of each cluster = the probability of that category in the ddirch distribution
  
  
  psi~ dunif(0,1)			#exists or not		
  
  
 juvi1 <- (sum(z*w <= 13) - sum(z*w <1))/N
  juvi2 <- (sum(z*w < 21) - sum(z*w <13))/N
  juvi3 <- sum(z*w >= 21)/N
  
  Occ <- sum(o)/(nind+nz)
  N <- sum(w)		
  D <- N/(2*L*Bx)			#burrow density
  Nt <- N*Occ 			 
  Dt <- Nt/(2*L*Bx)			#tort density
  small <- (sum(z*w*o < 13) - sum(z*w*o <1))/Nt
  big <- sum(z*w*o >= 22)/Nt
  med <- (sum(z*w*o < 22) - sum(z*w*o <13))/Nt
}
"

modelstring.PCV = "
model
{
  for (i in 1:(nind +nz)) {
  w[i] ~ dbern(psi)					#augmentation 
  x[i] ~ dunif(0,Bx)					#distance from line; Bx = max(distances) 
  
  z[i] ~ dgamma(a[i],c.beta[i])T(4,65)		#covariate                
  a[i] <- shape[clust[i]]		## a depends on which cluster the size comes from
  c.beta[i] <- betaClust[clust[i]]	#precision is allowed to vary between clusters
  clust[i] ~ dcat( pClust[1:Nclust] )	## clusters are defined as categories, assuming Nclust clusters
  
  v[i] ~ dbeta(d,e)T(.05,.95)				## vegetation is unknown so beta prior
  sigma[i] <- exp(sigma.int+sigma.beta*z[i]+sigma.gamma*v[i])  #sigma of detection
  logp[i] <- -((x[i]*x[i])/(2*sigma[i]*sigma[i]))	#This is the normal distribution with an adjustment for covs
  p[i] <- exp(logp[i])
  
 
  mu[i] <- w[i]*p[i] 					# probabilty of seeing it for all the ones we DID see (where w[i] = 1)
  
  y[i] ~ dbern(mu[i])         #found vs. missed
  
  o[i]~ dbin(o2[i], 1)        #occupancy
  logit(o2[i]) <- o.int + z.beta*z[i]						
  }
  
  for (q in 1:q) {
  v2[q] ~ dbeta (d,e)T(.05,.95)		# all veg measurements at the site
  }
  
  p.online <- 1		#estimated detection on line for 4 cm burrows
  b.point <- 4
  
  sigma.int~ dnorm(0,s.int.tau)T(0,)
  s.int.tau <- 1/(s.int.sd*s.int.sd)
  s.int.sd ~ dunif(.00001,5)	
  sigma.beta~ dnorm(0,s.beta.tau)T(0,)
  s.beta.tau <- 1/(s.beta.sd*s.beta.sd)
  s.beta.sd ~ dunif(.00001,5)
  o.int~ dnorm(0,o.int.tau)
  o.int.tau <- 1/(o.int.sd*o.int.sd)
  o.int.sd ~ dunif(.00001,5)		
  z.beta~ dnorm(0,z.beta.tau)
  z.beta.tau <- 1/(z.beta.sd*z.beta.sd)
  z.beta.sd ~ dunif(.00001,5)	
  sigma.gamma~ dnorm(0,s.gamma.tau)T(,0)
  s.gamma.tau <- 1/(s.gamma.sd*s.gamma.sd)
  s.gamma.sd ~ dunif(.00001,5)
  
  d~dunif(.1,40)
  e~dunif(.1,40)
  
  for (clustIdx in 1: Nclust) {
  shape[clustIdx] ~ dunif(1,80)
  betaClust[clustIdx] ~ dunif(0.2,2)
  }
  
  pClust[1:Nclust] ~ ddirch(onesRepNclust) # probability of each cluster = the probability of that category in the ddirch distribution
  
  
  psi~ dunif(0,1)			#exists or not		
  
  
 juvi1 <- (sum(z*w <= 13) - sum(z*w <1))/N
  juvi2 <- (sum(z*w < 21) - sum(z*w <13))/N
  juvi3 <- sum(z*w >= 21)/N
  
  Occ <- sum(o)/(nind+nz)
  N <- sum(w)		
  D <- N/(2*L*Bx)			#burrow density
  Nt <- N*Occ 			 
  Dt <- Nt/(2*L*Bx)			#tort density
  small <- (sum(z*w*o < 13) - sum(z*w*o <1))/Nt
  big <- sum(z*w*o >= 22)/Nt
  med <- (sum(z*w*o < 22) - sum(z*w*o <13))/Nt
}
"

modelstring.IEV = "
  model
{
  ## Loop over burrows detected in LTDS (excluding ISU boxes) plus augmented burrows
  for (i in (nind.IS+1):(nind.IS+nind.LT + nz)) {
  w[i] ~ dbern(psi)					##augmentation 
  x[i] ~ dunif(0,Bx)					#distance from line for the missed ones; Bx = max(distances) 
  
  z[i] ~ dgamma(a[i],c.beta[i])T(4,65)		#covariate                
  a[i] <- shape[clust[i]]		## a depends on which cluster the size comes from
  c.beta[i] <- betaClust[clust[i]]	#precision is allowed to vary between clusters
  clust[i] ~ dcat( pClust[1:Nclust] )	## clusters are defined as categories, assuming Nclust clusters
  
  v[i] ~ dbeta(d,e)T(.05,.95)				## vegetation is unknown so beta prior
  sigma[i] <- exp(sigma.int+sigma.beta*z[i]+sigma.gamma*v[i])  #sigma of detection
  logp[i] <- -((x[i]*x[i])/(2*sigma[i]*sigma[i]))	#This is the normal distribution with an adjustment for covs
  p[i] <- exp(logp[i])*xi[i]
  xi[i] <- ifelse(z[i] < b.point, m*z[i]+intercept, 1) #if less than b.point, probability is linear; if larger than b.point, perfect detection on line
  
  mu[i] <- w[i]*p[i] 					## probabilty of seeing it for all the ones we DID see (where w[i] = 1)
  y[i] ~ dbern(mu[i])         ## found or missed
  
  o[i]~ dbin(o2[i], 1)        #occupancy
  logit(o2[i]) <- o.int + z.beta*z[i]	
  o.real[i] <- o[i]*w[i]
  }
  
  ## Loop over burrows detected in ISUs
  for (i in 1:nind.IS) {  
  w[i] ~ dbern(1)       ## forcing w[i] to take value 1
  x[i] ~ dunif(0,Bx)					#distance from line for the missed ones; Bx = max(distances) 
  
  z[i] ~ dgamma(a[i],c.beta[i])T(4,65)		                
  a[i] <- shape[clust[i]]		## a depends on which cluster the size comes from
  c.beta[i] <- betaClust[clust[i]]	#precision is allowed to vary between clusters
  clust[i] ~ dcat( pClust[1:Nclust] )	## clusters are defined as categories, assuming Nclust clusters
  
  v[i] ~ dbeta(d,e)T(.05,.95)				## vegetation is unknown so beta prior
  sigma[i] <- exp(sigma.int+sigma.beta*z[i]+sigma.gamma*v[i])	#log link for size
  logp[i] <- -((x[i]*x[i])/(2*sigma[i]*sigma[i]))	#This is the normal distribution with an adjustment for covs
  p[i] <- exp(logp[i])*xi[i]
  xi[i] <- ifelse(z[i] < b.point, m*z[i]+intercept, 1) #if less than b.point, probability is linear; if larger than b.point, perfect detection on line
  mu[i] <- p[i] 					## probabilty of seeing it for all the ones we DID see (where w[i] = 1)
  
  y[i] ~ dbern(mu[i])
  
  o[i]~ dbin(o2[i], 1)
  logit(o2[i]) <- o.int + z.beta*z[i]
  
  o.real[i] <- o[i]*w[i]
  }
  
  p.online ~ dunif(pmin, pmax)		#estimated detection on line for 4 cm burrows
  b.point ~ dunif(15,22)
  m <- (1-p.online)/(b.point-4) 	#slope for detection on the line for smaller burrows		
  intercept <- p.online-(4*m)	## finding intercept via the detection of the 4 cm burrow 
  
  for (q in 1:q) {
  v2[q] ~ dbeta (d,e)T(.05,.95)		# all veg measurements at the site
  }
  
  sigma.int~ dnorm(0,s.int.tau)T(,)
  s.int.tau <- 1/(s.int.sd*s.int.sd)
  s.int.sd ~ dunif(.00001,5)
  sigma.beta~ dnorm(0,s.beta.tau)T(0,)
  s.beta.tau <- 1/(s.beta.sd*s.beta.sd)
  s.beta.sd ~ dunif(.00001,5)
  o.int~ dnorm(0,o.int.tau)
  o.int.tau <- 1/(o.int.sd*o.int.sd)
  o.int.sd ~ dunif(.00001,5)		
  z.beta~ dnorm(0,z.beta.tau)
  z.beta.tau <- 1/(z.beta.sd*z.beta.sd)
  z.beta.sd ~ dunif(.00001,5)	
  sigma.gamma~ dnorm(0,s.gamma.tau)T(,0)
  s.gamma.tau <- 1/(s.gamma.sd*s.gamma.sd)
  s.gamma.sd ~ dunif(.00001,5)
  
  d~dunif(.1,40)
  e~dunif(.1,40)
  
  

  for (clustIdx in 1: Nclust) {
  shape[clustIdx] ~ dunif(1,80)
  betaClust[clustIdx] ~ dunif(0.2,2)
  }
  
  pClust[1:Nclust] ~ ddirch(onesRepNclust) ## probability of each cluster = the probability of that category in the ddirch distribution
  psi~ dunif(0,1)			#exists or not		
  
  N <- sum(w)      ## w vector has (nind.IS + nind.LT) ones, plus psi fraction of nz's
  Occ <- sum(o.real)/N
  D <- N/(2*L*Bx)
  Nt <- N*Occ
  Dt <- D*Occ		#tort density
  
  juvi1 <- sum(z < 13)/(nind.IS+nind.LT + nz)
  juvi2 <-  (sum(z < 21)- sum(z <13))/(nind.IS+nind.LT + nz)
  juvi3 <- sum(z > 22)/(nind.IS+nind.LT + nz)
  
}
"

modelstring.IE = "
  model
{
  ## Loop over burrows detected in LTDS (excluding ISU boxes) plus augmented burrows
  for (i in (nind.IS+1):(nind.IS+nind.LT + nz)) {
  w[i] ~ dbern(psi)					##augmentation 
  x[i] ~ dunif(0,Bx)					#distance from line for the missed ones; Bx = max(distances) 
  
  z[i] ~ dgamma(a[i],c.beta[i])T(4,65)		#covariate                
  a[i] <- shape[clust[i]]		## a depends on which cluster the size comes from
  c.beta[i] <- betaClust[clust[i]]	#precision is allowed to vary between clusters
  clust[i] ~ dcat( pClust[1:Nclust] )	## clusters are defined as categories, assuming Nclust clusters
  
  sigma[i] <- exp(sigma.int+sigma.beta*z[i])  #sigma of detection
  logp[i] <- -((x[i]*x[i])/(2*sigma[i]*sigma[i]))	#This is the normal distribution with an adjustment for covs
  p[i] <- exp(logp[i])*xi[i]
  xi[i] <- ifelse(z[i] < b.point, m*z[i]+intercept, 1) #if less than b.point, probability is linear; if larger than b.point, perfect detection on line
  
  mu[i] <- w[i]*p[i] 					## probabilty of seeing it for all the ones we DID see (where w[i] = 1)
  y[i] ~ dbern(mu[i])         ## found or missed
  
  o[i]~ dbin(o2[i], 1)        #occupancy
  logit(o2[i]) <- o.int + z.beta*z[i]	
  o.real[i] <- o[i]*w[i]
  }
  
  ## Loop over burrows detected in ISUs
  for (i in 1:nind.IS) {  
  w[i] ~ dbern(1)       ## forcing w[i] to take value 1
  x[i] ~ dunif(0,Bx)					#distance from line for the missed ones; Bx = max(distances) 
  
  z[i] ~ dgamma(a[i],c.beta[i])T(4,65)		                
  a[i] <- shape[clust[i]]		## a depends on which cluster the size comes from
  c.beta[i] <- betaClust[clust[i]]	#precision is allowed to vary between clusters
  clust[i] ~ dcat( pClust[1:Nclust] )	## clusters are defined as categories, assuming Nclust clusters
  
  sigma[i] <- exp(sigma.int+sigma.beta*z[i])	#log link for size
  logp[i] <- -((x[i]*x[i])/(2*sigma[i]*sigma[i]))	#This is the normal distribution with an adjustment for covs
  p[i] <- exp(logp[i])*xi[i]
  xi[i] <- ifelse(z[i] < b.point, m*z[i]+intercept, 1) #if less than b.point, probability is linear; if larger than b.point, perfect detection on line
  mu[i] <- p[i] 					## probabilty of seeing it for all the ones we DID see (where w[i] = 1)
  
  y[i] ~ dbern(mu[i])
  
  o[i]~ dbin(o2[i], 1)
  logit(o2[i]) <- o.int + z.beta*z[i]
  
  o.real[i] <- o[i]*w[i]
  }
  
  p.online ~ dunif(pmin, pmax)		#estimated detection on line for 4 cm burrows
  b.point ~ dunif(15,22)
  m <- (1-p.online)/(b.point-4) 	#slope for detection on the line for smaller burrows		
  intercept <- p.online-(4*m)	## finding intercept via the detection of the 4 cm burrow 
  
  
  sigma.int~ dnorm(0,s.int.tau)T(,)
  s.int.tau <- 1/(s.int.sd*s.int.sd)
  s.int.sd ~ dunif(.00001,5)
  sigma.beta~ dnorm(0,s.beta.tau)T(0,)
  s.beta.tau <- 1/(s.beta.sd*s.beta.sd)
  s.beta.sd ~ dunif(.00001,5)
  o.int~ dnorm(0,o.int.tau)
  o.int.tau <- 1/(o.int.sd*o.int.sd)
  o.int.sd ~ dunif(.00001,5)		
  z.beta~ dnorm(0,z.beta.tau)
  z.beta.tau <- 1/(z.beta.sd*z.beta.sd)
  z.beta.sd ~ dunif(.00001,5)	
  
  
  
  for (clustIdx in 1: Nclust) {
  shape[clustIdx] ~ dunif(1,80)
  betaClust[clustIdx] ~ dunif(0.2,2)
  }
  
  pClust[1:Nclust] ~ ddirch(onesRepNclust) ## probability of each cluster = the probability of that category in the ddirch distribution
  psi~ dunif(0,1)			#exists or not		
  
  N <- sum(w)      ## w vector has (nind.IS + nind.LT) ones, plus psi fraction of nz's
  Occ <- sum(o.real)/N
  D <- N/(2*L*Bx)
  Nt <- N*Occ
  Dt <- D*Occ		#tort density
  
  juvi1 <- sum(z < 13)/(nind.IS+nind.LT + nz)
  juvi2 <-  (sum(z < 21)- sum(z <13))/(nind.IS+nind.LT + nz)
  juvi3 <- sum(z > 22)/(nind.IS+nind.LT + nz)
  
}
"
modelstring.PEV = "
  model
{
  ## Loop over burrows detected in LTDS (excluding ISU boxes) plus augmented burrows
  for (i in (nind.IS+1):(nind.IS+nind.LT + nz)) {
  w[i] ~ dbern(psi)					##augmentation 
  x[i] ~ dunif(0,Bx)					#distance from line for the missed ones; Bx = max(distances) 
  
  z[i] ~ dgamma(a[i],c.beta[i])T(4,65)		#covariate                
  a[i] <- shape[clust[i]]		## a depends on which cluster the size comes from
  c.beta[i] <- betaClust[clust[i]]	#precision is allowed to vary between clusters
  clust[i] ~ dcat( pClust[1:Nclust] )	## clusters are defined as categories, assuming Nclust clusters
  
  v[i] ~ dbeta(d,e)T(.05,.95)				## vegetation is unknown so beta prior
  sigma[i] <- exp(sigma.int+sigma.beta*z[i]+sigma.gamma*v[i])  #sigma of detection
  logp[i] <- -((x[i]*x[i])/(2*sigma[i]*sigma[i]))	#This is the normal distribution with an adjustment for covs
  p[i] <- exp(logp[i])
  
  mu[i] <- w[i]*p[i] 					## probabilty of seeing it for all the ones we DID see (where w[i] = 1)
  y[i] ~ dbern(mu[i])         ## found or missed
  
  o[i]~ dbin(o2[i], 1)        #occupancy
  logit(o2[i]) <- o.int + z.beta*z[i]	
  o.real[i] <- o[i]*w[i]
  }
  
  ## Loop over burrows detected in ISUs
  for (i in 1:nind.IS) {  
  w[i] ~ dbern(1)       ## forcing w[i] to take value 1
  x[i] ~ dunif(0,Bx)					#distance from line for the missed ones; Bx = max(distances) 
  
  z[i] ~ dgamma(a[i],c.beta[i])T(4,65)		                
  a[i] <- shape[clust[i]]		## a depends on which cluster the size comes from
  c.beta[i] <- betaClust[clust[i]]	#precision is allowed to vary between clusters
  clust[i] ~ dcat( pClust[1:Nclust] )	## clusters are defined as categories, assuming Nclust clusters
  
  v[i] ~ dbeta(d,e)T(.05,.95)				## vegetation is unknown so beta prior
  sigma[i] <- exp(sigma.int+sigma.beta*z[i]+sigma.gamma*v[i])	#log link for size
  logp[i] <- -((x[i]*x[i])/(2*sigma[i]*sigma[i]))	#This is the normal distribution with an adjustment for covs
  p[i] <- exp(logp[i])
  mu[i] <- p[i] 					## probabilty of seeing it for all the ones we DID see (where w[i] = 1)
  
  y[i] ~ dbern(mu[i])
  
  o[i]~ dbin(o2[i], 1)
  logit(o2[i]) <- o.int + z.beta*z[i]
  
  o.real[i] <- o[i]*w[i]
  }
  
  p.online <- 1		#estimated detection on line for 4 cm burrows
  b.point <- 4

  for (q in 1:q) {
  v2[q] ~ dbeta (d,e)T(.05,.95)		# all veg measurements at the site
  }
  
  sigma.int~ dnorm(0,s.int.tau)T(,)
  s.int.tau <- 1/(s.int.sd*s.int.sd)
  s.int.sd ~ dunif(.00001,5)
  sigma.beta~ dnorm(0,s.beta.tau)T(0,)
  s.beta.tau <- 1/(s.beta.sd*s.beta.sd)
  s.beta.sd ~ dunif(.00001,5)
  o.int~ dnorm(0,o.int.tau)
  o.int.tau <- 1/(o.int.sd*o.int.sd)
  o.int.sd ~ dunif(.00001,5)		
  z.beta~ dnorm(0,z.beta.tau)
  z.beta.tau <- 1/(z.beta.sd*z.beta.sd)
  z.beta.sd ~ dunif(.00001,5)	
  sigma.gamma~ dnorm(0,s.gamma.tau)T(,0)
  s.gamma.tau <- 1/(s.gamma.sd*s.gamma.sd)
  s.gamma.sd ~ dunif(.00001,5)
  
  d~dunif(.1,40)
  e~dunif(.1,40)
  
  
  
  for (clustIdx in 1: Nclust) {
  shape[clustIdx] ~ dunif(1,80)
  betaClust[clustIdx] ~ dunif(0.2,2)
  }
  
  pClust[1:Nclust] ~ ddirch(onesRepNclust) ## probability of each cluster = the probability of that category in the ddirch distribution
  psi~ dunif(0,1)			#exists or not		
  
  N <- sum(w)      ## w vector has (nind.IS + nind.LT) ones, plus psi fraction of nz's
  Occ <- sum(o.real)/N
  D <- N/(2*L*Bx)
  Nt <- N*Occ
  Dt <- D*Occ		#tort density
  
  juvi1 <- sum(z < 13)/(nind.IS+nind.LT + nz)
  juvi2 <- (sum(z < 21)- sum(z <13))/(nind.IS+nind.LT + nz)
  juvi3 <- sum(z > 22)/(nind.IS+nind.LT + nz)
  
}
"

modelstring.PE = "
  model
{
  ## Loop over burrows detected in LTDS (excluding ISU boxes) plus augmented burrows
  for (i in (nind.IS+1):(nind.IS+nind.LT + nz)) {
  w[i] ~ dbern(psi)					##augmentation 
  x[i] ~ dunif(0,Bx)					#distance from line for the missed ones; Bx = max(distances) 
  
  z[i] ~ dgamma(a[i],c.beta[i])T(4,65)		#covariate                
  a[i] <- shape[clust[i]]		## a depends on which cluster the size comes from
  c.beta[i] <- betaClust[clust[i]]	#precision is allowed to vary between clusters
  clust[i] ~ dcat( pClust[1:Nclust] )	## clusters are defined as categories, assuming Nclust clusters
  
  sigma[i] <- exp(sigma.int+sigma.beta*z[i])  #sigma of detection
  logp[i] <- -((x[i]*x[i])/(2*sigma[i]*sigma[i]))	#This is the normal distribution with an adjustment for covs
  p[i] <- exp(logp[i])
  
  mu[i] <- w[i]*p[i] 					## probabilty of seeing it for all the ones we DID see (where w[i] = 1)
  y[i] ~ dbern(mu[i])         ## found or missed
  
  o[i]~ dbin(o2[i], 1)        #occupancy
  logit(o2[i]) <- o.int + z.beta*z[i]	
  o.real[i] <- o[i]*w[i]
  }
  
  ## Loop over burrows detected in ISUs
  for (i in 1:nind.IS) {  
  w[i] ~ dbern(1)       ## forcing w[i] to take value 1
  x[i] ~ dunif(0,Bx)					#distance from line for the missed ones; Bx = max(distances) 
  
  z[i] ~ dgamma(a[i],c.beta[i])T(4,65)		                
  a[i] <- shape[clust[i]]		## a depends on which cluster the size comes from
  c.beta[i] <- betaClust[clust[i]]	#precision is allowed to vary between clusters
  clust[i] ~ dcat( pClust[1:Nclust] )	## clusters are defined as categories, assuming Nclust clusters
  
  sigma[i] <- exp(sigma.int+sigma.beta*z[i])	#log link for size
  logp[i] <- -((x[i]*x[i])/(2*sigma[i]*sigma[i]))	#This is the normal distribution with an adjustment for covs
  p[i] <- exp(logp[i])
  mu[i] <- p[i] 					## probabilty of seeing it for all the ones we DID see (where w[i] = 1)
  
  y[i] ~ dbern(mu[i])
  
  o[i]~ dbin(o2[i], 1)
  logit(o2[i]) <- o.int + z.beta*z[i]
  
  o.real[i] <- o[i]*w[i]
  }
  
  p.online <- 1		#estimated detection on line for 4 cm burrows
  b.point <- 4
  
  sigma.int~ dnorm(0,s.int.tau)T(,)
  s.int.tau <- 1/(s.int.sd*s.int.sd)
  s.int.sd ~ dunif(.00001,5)
  sigma.beta~ dnorm(0,s.beta.tau)T(0,)
  s.beta.tau <- 1/(s.beta.sd*s.beta.sd)
  s.beta.sd ~ dunif(.00001,5)
  o.int~ dnorm(0,o.int.tau)
  o.int.tau <- 1/(o.int.sd*o.int.sd)
  o.int.sd ~ dunif(.00001,5)		
  z.beta~ dnorm(0,z.beta.tau)
  z.beta.tau <- 1/(z.beta.sd*z.beta.sd)
  z.beta.sd ~ dunif(.00001,5)	
  
  for (clustIdx in 1: Nclust) {
  shape[clustIdx] ~ dunif(1,80)
  betaClust[clustIdx] ~ dunif(0.2,2)
  }
  
  pClust[1:Nclust] ~ ddirch(onesRepNclust) ## probability of each cluster = the probability of that category in the ddirch distribution
  psi~ dunif(0,1)			#exists or not		
  
  N <- sum(w)      ## w vector has (nind.IS + nind.LT) ones, plus psi fraction of nz's
  Occ <- sum(o.real)/N
  D <- N/(2*L*Bx)
  Nt <- N*Occ
  Dt <- D*Occ		#tort density
  
  juvi1 <- sum(z < 13)/(nind.IS+nind.LT + nz)
  juvi2 <- (sum(z < 21)- sum(z <13))/(nind.IS+nind.LT + nz)
  juvi3 <- sum(z > 22)/(nind.IS+nind.LT + nz)
  
}
"

############################# Create data, initials, etc.########################################
Burrs <- data.frame(dist = Burrows$Dist, size = Burrows$Diameter,
                     Occ = Burrows$Occ, Found = Burrows$Found)
ifelse((chosenmodel == "111" | chosenmodel == "211" | chosenmodel == "121" |chosenmodel == "221"),
 Burrs$Veg <- Burrows$Veg,
 Burrs$Veg <- rep(.1,nrow(Burrs)))
Burrs <- subset(Burrs, Burrs$size >0)



######################################### Tortoise Triangle Code ############




###  Packages required:  {rgl}, {geometry}


#################################################################################################
#################################################################################################
###  ___________________Antecedent functions: ___________________________________________________

###  find parameters of a beta distribution, given mean and stddev
beta.par.findr <- function(par, mn, sd) {
  var <- sd^2
  a <- par[1]
  b <- par[2]
  this.mn <- a/(a+b)
  this.var <- (a*b)/((a+b)^2 * (a+b+1))
  #  wts <- c(mn,var)/(mn+var)
  #  wts[2]*abs(mn - this.mn) + wts[1]*abs(var - this.var)
  abs(mn - this.mn)/mn + abs(var - this.var)/sd
}  


###  find parameters of a gamma distribution, given mean and stddev
gamma.par.findr <- function(par, mn, sd) {
  #  var <- sd^2
  a <- par[1]
  s <- par[2]
  this.mn <- a*s
  this.sd <- sqrt(a*s^2)
  #  wts <- c(mn,var)/(mn+var)
  abs(mn - this.mn)/mn + abs(sd - this.sd)/sd
}  


###  display a growth curve:  tortoises begin the hatchling stage not at size = 0mm, but 50mm.
vB.50 <- function(age, A, k) {
  (A - 50) * (1-exp(-k*age)) + 50
}
# curve(vB.50(x,306,0.05), from = 0, to = 80)


###  because two distributions (for A and k) are involved, just derive the desired ages from the from the set of curves, treat these as a sample and fit a distribution.
###  hatchlings start life at 50mm !!
inv.vB.50 <- function(sz, A, k) {
  log((A-50)/(A-sz))/k
}
#curve(inv.vB(x,306,0.05), from = 50, to = 304)


####  Ack, I forgot, R doesn't do cross-products!
### found this:  https://stackoverflow.com/questions/15162741/what-is-rs-crossproduct-function
#CrossProduct <- function(x, y, s=1:3) {
#  Index3D <- function(i) (i - 1) %% 3 + 1
#  return (x[Index3D(s + 1)] * y[Index3D(s + 2)] -
#          x[Index3D(s + 2)] * y[Index3D(s + 1)])
#}


###  find inter-point distance, even if vectors come in as 1-row dataframes:
dist.fun <- function (u,v) {
  u <- drop(as.matrix(u))
  v <- drop(as.matrix(v))
  dif <- v - u
  sqrt(drop(dif %*% dif)) 
}

#op <- par(mar = rep(.5,4)); on.exit(par(op))

###  ternary plot:
tri.plot <- function (pts, centr, cols, tri, mx.f, colorPal, mcp = NULL, kde = NULL) {
  if ( (is.null(mcp) && is.null(kde)) || is.null(c(mcp,kde)) )stop('You must supply an object for either "mcp=" or "kde=" (but not both)!')
  op <- par(); on.exit(par(op))
  x11(width = 10, height = 8)
  layout(matrix(c(1, 2), ncol = 2), widths = c(1, 0.2))
  par(mar = c(1,1,1,1), ann = F, xaxt = "n", yaxt = "n", bty = "n")
  plot(rbind(tri, tri[1,]), xlim = c(0,1), ylim = c(0,1), type = "l")
  points(tri, pch = 19, col = "white", cex = 3)
  text(x = tri, labels = rownames(tri))
  #  points(pts, col = f.col)
  points(pts, col = cols)
  points(rbind(centr), pch = 3, cex = 5, lwd = 4)
  points(rbind(centr), pch = 3, cex = 5, lwd = 0.5, col = "white")
  
  ###  MCP, or KDE?:
  if (!is.null(mcp)) {
    apply(mcp, MAR = 1, FUN = function (v) {lines(rbind(pts[v[1],], pts[v[2],])) })
  } else {
    contour(kde, levels = 0.05, add = T)
  }
  
  u <- par("usr")
  text(x = u[1] + 0.2*(u[2]-u[1]), y = u[3] + 0.8*(u[4]-u[3]), labels = paste0("n = ", dim(pts)[1])) 
  
  ###  Color legend
  levs <- pretty(c(0,mx.f), floor(mx.f/2))
  par(mar = c(5,0,4,0)+0.1, ann = T)
  plot.new()
  plot.window(xlim = c(0, 1), ylim = range(levs))#, xaxs = "i", yaxs = "i")
  rect(0, levs[-length(levs)], 0.2, levs[-1], col = colorPal(length(levs)))
  text(x = 0.5, y = levs[-1] - 1, labels = levs[-1])
  text(x = 0.5, y = mx.f*1.1, labels = expression(bolditalic(f)), cex = 3, xpd = T)   
}

# tri.plot(pts = cart.cut.med, centr = cart.med, cols = f.col.cut.med, tri = tri, colorPal = cp, mx.f = max.f, mcp = cart.cut.mcp.ind)

#pts = cart.cut.med; centr = cart.med; cols = f.col.cut.med; tri = tri; colorPal = cp; mx.f = max.f
###  Caswell pg. 161 shows the more thorough way to estimate gamma's:
###  `T` is the time spent in the stage, `sigma` is the survival probability:
#  gamma = (sigma/lambda)^T - (sigma/lambda)^(T-1)  /  ( (sigma/lambda)^T - 1 )
gamma.fun <- function (T, sigma, lambda) {
  (sigma/lambda)^T - (sigma/lambda)^(T-1)  /  ( (sigma/lambda)^T - 1 )
}  



#################################################################################################
#################################################################################################
###  __________________________Main function: ___________________________________________________

simFun <- function(
  n.iter = 10000,		###  initial number of iterations (number used in the end will be smaller, since they are filtered according to "f.max=")
  sr = 0.5,			###  sex ratio
  hatch.surv = c(0.1, 0.01),	###  survival distributions defined like "hatch.surv = c(mean, SD)"
  juv.surv = c(0.6, 0.1),
  sa.surv = c(0.8, 0.05),
  male.surv = c(0.9, 0.01),
  fem.surv = c(0.95, 0.01),
  max.f = 12,			###  maximum number of hatchlings produced each year per female.  Simulated populations are `culled` according to this threshold.
  sr.accept = 0.8,		###  maximum acceptable value of the fem/(fem + mal) AND the mal/(fem + mal) sex ratio (so it is a bandpass filter centered on 0.5) -- any simulated pops not meeting the threshold will be culled.
  sa.accept = 0.01,			###  The ratio of subadults to adults should never be allowed to be too low -- this will be enforced as the lower limit (i.e., as a high-pass filter).
  lambda = 1,			###  value of the annual population growth rate, for all simulated populations
  ####################
  ####  Default individual growth parameters are for Green Grove at Ichauway, as reported in Tuberville et al.
  mn.A.f = 306.5,		###  mean value of max carapace length, for females
  mn.A.m = 289.3,		###  mean value of max carapace length, for males
  mn.k.f = 0.056,		###  mean value of rate coefficient, for females
  mn.k.m = 0.061,		###  mean value of rate coefficient for females
  sd.A.f = 6,			###  stddev of the mean value of max carapace length, for females
  sd.A.m = 5,			###  stddev of the mean value of max carapace length, for males
  sd.k.f = 0.0045,		###  stddev of the mean value of rate coefficient, for females
  sd.k.m = 0.005		###  stddev of the mean value of rate coefficient, for males
  ####################
  #  plots.3d = TRUE,		###  should some nifty 3d plots be produced, showing barycentric points in R^3 ?
  #  mcp.thresh = 0.95	###  cutoff for the minimum convex polygon to be drawn around the populations, on a ternary plot
) {
  
  require(geometry)
  
  s.nms <- c("hatch", "juv", "sub", "male", "female")
  s <- matrix(NA, ncol = length(s.nms), nrow = n.iter)
  colnames(s) <- s.nms
  
  s.lst <- list()
  s.lst$h <- hatch.surv  #c(0.1, 0.01)
  s.lst$j <- juv.surv   #c(0.6, 0.1)
  s.lst$sa <- sa.surv  #c(0.8, 0.05)
  s.lst$m <- male.surv  #c(0.9, 0.01)
  s.lst$f <- fem.surv  #c(0.95, 0.01)
  
  s.lst <- lapply(s.lst, FUN = `names<-`, c("mean", "sd"))
  
  s.mat <- sapply(s.lst,
                  FUN = function (v) {
                    shp <- optim(par = c(10,10), fn = beta.par.findr, mn = v["mean"], sd = v["sd"])$par
                    rbeta(n.iter, shape1 = shp[1], shape2 = shp[2])})
  
  ### Matrix plan:  keep sexes separate.
  ### P's are on the diagonal, G's below it.
  
  #  0           0       0        0        0       0       f
  #  s.h*(1-sr)  P.j.M
  #              G.j.M   P.sa.M
  #                      G.sa.M   P.ad.M  
  #  s.h*sr                               P.j.F
  #                                       G.j.F   P.sa.F  
  #                                               G.sa.F   P.ad.M
  #                                                       
  
  ####  growth model beeswax:
  gro.par <- array(c(mn.A.f,
                     mn.A.m,
                     mn.k.f,
                     mn.k.m,
                     sd.A.f,
                     sd.A.m,
                     sd.k.f,
                     sd.k.m),
                   dim = c(2,2,2),
                   dimnames = list(c("female","male"), c("A","k"), c("mean","sd")))
  
  dur.lst <- list()
  
  rnd.fem <- cbind(rnorm(n.iter, mean = gro.par["female","A","mean"], sd = gro.par["female","A","sd"]), rnorm(1000, mean = gro.par["female","k","mean"], sd = gro.par["female","k","sd"]))
  rnd.mal <- cbind(rnorm(n.iter, mean = gro.par["male","A","mean"], sd = gro.par["male","A","sd"]), rnorm(1000, mean = gro.par["male","k","mean"], sd = gro.par["male","k","sd"]))
  
  #### and oops, hatchlings need to begin at 50mm !!
  
  dur.lst$sub.f <- inv.vB.50(sz = 150,
                             A = rnd.fem[,1],
                             k = rnd.fem[,2])
  
  dur.lst$ad.f <- inv.vB.50(sz = 230,
                            A = rnd.fem[,1],
                            k = rnd.fem[,2])
  
  dur.lst$sub.m <- inv.vB.50(sz = 150,
                             A = rnd.mal[,1],
                             k = rnd.mal[,2])
  
  dur.lst$ad.m <- inv.vB.50(sz = 230,
                            A = rnd.mal[,1],
                            k = rnd.mal[,2])
  
  
  
  ### so:  huh, well this "gamma.fun()" seems to fail (i.e., gives gamma > 1) when durations are short and survival high.  Maybe I'm not using the resulting gamma value properly? 
  #with(dur.lst, gamma.j.F <<- gamma.fun(T = sub.f - 1, sigma = s.mat[,"j"], lambda = lambda))
  #with(dur.lst, gamma.j.M <<- gamma.fun(T = sub.m - 1, sigma = s.mat[,"j"], lambda = lambda))
  #with(dur.lst, gamma.sa.F <<- gamma.fun(T = ad.f - sub.f, sigma = s.mat[,"sa"], lambda = lambda))
  #with(dur.lst, gamma.sa.M <<- gamma.fun(T = ad.m - sub.m, sigma = s.mat[,"sa"], lambda = lambda))
  
  ###  So for now:
  with(dur.lst, gamma.j.F <<- 1/(sub.f - 1))
  with(dur.lst, gamma.j.M <<- 1/(sub.m - 1))
  with(dur.lst, gamma.sa.F <<- 1/(ad.f - sub.f))
  with(dur.lst, gamma.sa.M <<- 1/(ad.m - sub.m))
  
  
  P.j.F <- s.mat[,"j"] * (1 - gamma.j.F)
  G.j.F <- s.mat[,"j"] * gamma.j.F
  
  P.j.M <- s.mat[,"j"] * (1 - gamma.j.M)
  G.j.M <- s.mat[,"j"] * gamma.j.M
  
  P.sa.F <- s.mat[,"sa"] * (1 - gamma.sa.F)
  G.sa.F <- s.mat[,"sa"] * gamma.sa.F
  
  P.sa.M <- s.mat[,"sa"] * (1 - gamma.sa.M)
  G.sa.M <- s.mat[,"sa"] * gamma.sa.M
  
  
  # check:
  # (P.sa + G.sa.m + G.sa.f)/s.mat[,"sa"]
  #  all 1's => ok!
  
  ###  make the matrices:
  sz <- ncol(s.mat) + 2
  A <- array(0, dim = c(sz,sz,n.iter))
  # A[1,sz,] <- f
  A[2,1,] <- (1-sr) * s.mat[,"h"]       ## move male hatchlings (that survive) on to j.F stage
  A[2,2,] <- P.j.M
  A[3,2,] <- G.j.M
  A[3,3,] <- P.sa.M
  A[4,3,] <- G.sa.M
  A[4,4,] <- s.mat[,"m"]
  A[5,1,] <- sr * s.mat[,"h"]   ## move female hatchlings (that survive) on to j.M stage
  A[5,5,] <- P.j.F
  A[6,5,] <- G.j.F
  A[6,6,] <- P.sa.F
  A[7,6,] <- G.sa.F
  A[7,7,] <- s.mat[,"f"]
  
  
  ###  OK, from Caswell p.73, the 'characterstic equation' of projection matrix A is:
  ###  det(A - λ*I) = 0
  
  ###  for my particular structure of 'A', then, we may solve for fecundity thus:
  #det(A - λ*I) = 0
  
  # Let m = A - λ*I
  
  #then:
  ####  if females are in the bottom-right section of A (and f in the upper right):________
  #-λ * det(m[2:7,2:7]) + (-1^(sz-1)) * f * det(m[2:7,1:(sz-1)]) = 0
  ###  because A[1,sz,] <- f, which is 7 ----> so it'll be positive!!!
  #so:
  #f = λ * ( det(m[2:7,2:7]) / det(m[2:7,c(1:ncol(s.mat)-2,ncol(s.mat):7)]) )
  
  ###  R-vian:
  #nr <- dim(A)[1]
  d <- diag(lambda, sz)
  
  m.arr <- A - array(d, dim = dim(A))
  
  
  #f < lambda * det(m[2:5,2:5]) / det(m[2:5,1:4])
  f <- apply(m.arr, MAR = 3, FUN = function (m) { ((-1)^(sz-1)) * lambda * ( det(m[2:sz,2:sz]) / det(m[2:sz,1:(sz-1)]) ) })
  
  ###  This results in some truly ridiculous values of f:
  # hist(f, xlim = c(0,200), breaks = 10000)
  
  ###  Filter #1: fecundity shouldn't be too high.
  ok.f <- which(f < max.f)
  
  ###  Now replace the 'f' cell in each matrix A:
  new.A <- A[,,ok.f]
  new.A[1,sz,] <- f[ok.f]
  
  ###  Calculate stable age distribution: the dominant right eigenvector of "new.A":
  stable.stg <- apply(new.A, MAR = 3, FUN = function (mat) {v <- as.numeric(eigen(mat, symmetric = F)$vectors[,1])
  ind <- ifelse(v[1] < 0, -1, 1)
  v * ind})
  
  ###  Find sex ratio of adults, at equillibrium.
  ad.sr <- stable.stg[sz,]/(stable.stg[sz,] + stable.stg[(1+((sz-1)/2)),])
  sa.rat <- (stable.stg[sz-1,] + stable.stg[(sz-1)/2,])/(stable.stg[sz,] + stable.stg[(1+((sz-1)/2)),])
  
  
  ###  Filter #2: 
  ###  A) sex ratio in adults shouldn't be too skewed.  This is a bandpass filter of width 2*sr.accept, centered on 0.5.
  ###  A) ratio of subadults to adults shouldn't be allowed to be too low.  A high-pass filter with lower threshold 'sa.accept'
  ###  Important to keep track of the fact that 'new.A' and 'stable.stg' have ALREADY BEEN FILTERED by 'ok.f'
  ok.2 <- which(ad.sr < sr.accept & ad.sr > (1 - sr.accept) & sa.rat > sa.accept)
  
  
  ###  Notice the necessity of the nested index 'ok.f[ok.sr]' here.
  ###  Index 'ok' is appropriate for filtering objects that were not previously filtered (or had ancestors filtered) by 'ok.f':
  ok <- ok.f[ok.2]
  
  
  ###  Summarize the distributions of population parameters, following filtering:
  new.s.sum <- t(apply(s.mat[ok,], MAR = 2, FUN = function (v) {
    c(mean(v), sd(v), quantile(v, c(0.05,0.25,0.5,0.75,0.95))) }))
  colnames(new.s.sum)[1:2] <- c("mean", "sd")
  
  ###  Filter the 'stable.stg' matrix:
  stable.stg.ok <- stable.stg[,ok.2]
  rm(stable.stg)   ###  try to avoid confusion
  
  ###  Combine females and males:
  stabl.stg.comb <- rbind(stable.stg.ok[1,], stable.stg.ok[2:(1+((sz-1)/2)),] + stable.stg.ok[(2+((sz-1)/2)):sz,])
  rm(stable.stg.ok)   ###  try to avoid confusion
  
  ###  Drop hatchlings.
  nohatch <- stabl.stg.comb[-1,]
  rm(stabl.stg.comb)   ###  try to avoid confusion
  
  ###  normalize "juv", "sa" and "ad" proportions, so they sum to 1.  These, then, are 'barycentric' coordinates.
  stbl.nohatch.nrm <- nohatch/rep(colSums(nohatch), each = nrow(nohatch))
  
  #### "simplex points": just "stbl.nohatch.nrm" put into a data.frame
  simp.pts <- as.data.frame(t(stbl.nohatch.nrm))
  names(simp.pts) <- c("juv", "sa", "ad")
  rm(stbl.nohatch.nrm)   ###  try to avoid confusion
  
  ###  Vertices of the Cartesian (equilateral) triangle to project barycentric points into:  
  tri <- rbind(rep(0,2), c(1,0), c(0.5,1/(2*tan(pi/6))))
  rownames(tri) <- c(names(simp.pts))
  
  ###  Hah, well, the {geometry} packages already has a bary2cart() function !
  cart.pts <- bary2cart(X = tri, Beta = as.matrix(simp.pts))
  
  ###  gather inputs and outputs:
  out <- list(bary.pts = simp.pts,
              tri = tri,
              cart.pts = cart.pts,
              out.s = new.s.sum,
              f = f[ok],
              sim.inputs = list(
                surv = s.lst,
                growth = gro.par,
                max.f = max.f,
                lambda = lambda))
  
  return(out)
}



################################################################

###########  24 jun 2019.
###########    Probably better just to have a separate plotting function, eh?
library(grDevices)
simPlot <- function (sim, surv, raw.pt, method = c("mcp", "kde"), level = 0.95, ...) {   ### "..." goes to kde2d()
  #  if ( (is.null(mcp) && is.null(kde)) || is.null(c(mcp,kde)) )stop('You must supply an object for either "mcp=" or "kde=" (but not both)!')
  method <- method[1]
  surv <- survProc(surv, tri = sim$tri)
  #x11(width = 10, height = 8)
  jpeg(filename = "Tortoise_Triangle_Output.jpg", width = 10, height = 8, units = "in", type = "windows", res = 300)
  #op <- par(); on.exit(suppressWarnings(par(op)))
  #layout(matrix(c(1, 2), ncol = 2), widths = c(1, 0.2))
  par(mar = c(1,1,1,1), ann = F, xaxt = "n", yaxt = "n", bty = "n")
  #  tri <- rbind(rep(0,2), c(1,0), c(0.5,1/(2*tan(pi/6))))
  plot(rbind(sim$tri, sim$tri[1,]), xlim = c(0,1), ylim = c(0,.9), type = "l", lwd = 2)
  points(sim$tri, pch = 19, col = "white", cex = 7)
  text(x = sim$tri, labels = c("juv", "sa", "ad"), cex = 2)
  #  points(pts, col = f.col)
  
  points(surv, col = "red3", cex = 1.2, pch = 5)
  points(sim$cart.pts, col = "skyblue", cex = 1.2)
  points(raw.pt, col = "black", cex = 2, pch = 19)
  
  ###  centers of 2d distributions
  sim.centr <- apply(sim$cart.pts, MAR = 2, FUN = median)
  points(rbind(sim.centr), pch = 3, cex = 5, lwd = 4)
  points(rbind(sim.centr), pch = 3, cex = 5, lwd = 0.5, col = "white")
  surv.centr <- apply(surv, MAR = 2, FUN = median)
  points(rbind(surv.centr), pch = 3, cex = 5, lwd = 4)
  points(rbind(surv.centr), pch = 3, cex = 5, lwd = 0.5, col = "white")
  
  intr <- intsxn(sim = sim, surv = surv, method = method, level = level, ...) 
  
  if (method == "mcp") {
    apply(intr$ch1$hull, MAR = 1, FUN = function (v) {lines(rbind(intr$ch1$p[v[1],], intr$ch1$p[v[2],]), lwd =2) })
    apply(intr$ch2$hull, MAR = 1, FUN = function (v) {lines(rbind(intr$ch2$p[v[1],], intr$ch2$p[v[2],]), lwd =2) })
    ovrlp <- list(area = intr$ch$vol, prop.sim = intr$ch$vol/intr$ch1$vol, prop.surv = intr$ch$vol/intr$ch2$vol)
  } else {
    if (method == "kde") {
      contour(intr$sim.kde, levels = 1 - level, add = T)
      contour(intr$surv.kde, levels = 1 - level, add = T)
      ovrlp <- list(area = intr$area$intsxn, prop.sim = intr$area$intsxn/intr$area$sim, prop.surv = intr$area$intsxn/intr$area$surv)
    } else { stop('Somehow, "method=" was not one of "mcp" or "kde"...') }}
  
  u <- par("usr")
  polygon(c(-.0001,.5,0), c(0, .8760254,.9), col = "white", border = NA)
  polygon(c(1.00001,.5,1), c(.0001, .8760254,.9), col = "white", border = NA)
  polygon(c(0,1,1,0), c(.87, .87, 1, 1), col = "white", border = NA)
  lines(rbind(sim$tri, sim$tri[1,]),lwd = 2)
  points(sim$tri, pch = 19, col = "white", cex = 7)
  text(x = sim$tri, labels = c("juv", "sa", "ad"), cex = 2)
  
  dev.off()
  #text(x = u[1] + 0.2*(u[2]-u[1]), y = u[3] + 0.8*(u[4]-u[3]), labels = bquote(italic(n)[sim] == .(dim(sim$cart.pts)[1]))) 
  #text(x = u[1] + 0.2*(u[2]-u[1]), y = u[3] + 0.77*(u[4]-u[3]), labels = bquote(italic(n)[surv] == .(dim(surv)[1])))
  
  #text(x = u[1] + 0.2*(u[2]-u[1]), y = u[3] + 0.74*(u[4]-u[3]), labels = bquote(italic(A)[overlap]/italic(A)[sim] == .(round(ovrlp$prop.sim, 3))))
  #text(x = u[1] + 0.2*(u[2]-u[1]), y = u[3] + 0.71*(u[4]-u[3]), labels = bquote(italic(A)[overlap]/italic(A)[surv] == .(round(ovrlp$prop.surv, 3))))
  
  ###  Color legend
  #levs <- pretty(c(0,sim$sim.inputs$max.f), floor(sim$sim.inputs$max.f/2))
  #par(mar = c(5,0,4,0)+0.1, ann = T)
  #plot.new()
  #plot.window(xlim = c(0, 1), ylim = range(levs))#, xaxs = "i", yaxs = "i")
  #rect(0, levs[-length(levs)], 0.2, levs[-1], col = f.col(sim)$pal(length(levs)))
  #text(x = 0.5, y = levs[-1] - 1, labels = levs[-1])
  #text(x = 0.5, y = sim$sim.inputs$max.f*1.1, labels = expression(bolditalic(f)), cex = 3, xpd = T)
  
}

# sim <- simFun()
# simPlot(sim = sim, surv = survProc(tst.lst, tri = sim$tri))
# simPlot(sim = sim, surv = survProc(tst.lst, tri = sim$tri), method = "kde")

intsxn <- function (sim, surv, method = c("mcp", "kde"), level = 0.95, ...) {
  method <- method[1]
  surv <- survProc(surv, tri = sim$tri)
  if (method == "mcp") {
    mcp.sim <- mcp(mat = sim$cart.pts, level = level)
    mcp.surv <- mcp(mat = surv, level = level)
    intsxn <- intersectn(ps1 = mcp.sim$p, ps2 = mcp.surv$p)
  } else {
    if (method == "kde") {
      sim.kde <- kde2d(x = sim$cart.pts[,1], y = sim$cart.pts[,2], ...)
      sim.kde$z <- sim.kde$z/max(sim.kde$z)
      cntr.sim <- contourLines(sim.kde, levels = 1 - level)[[1]]
      
      surv.kde <- kde2d(x = surv[,1], y = surv[,2], ...)
      surv.kde$z <- surv.kde$z/max(surv.kde$z)
      cntr.surv <- contourLines(surv.kde, levels = 1 - level)[[1]]
      
      require(sf)
      area.intsxn <- st_area(st_intersection(st_polygon(list(cbind(cntr.surv$x, cntr.surv$y))), st_polygon(list(cbind(cntr.sim$x, cntr.sim$y)))))
      area.sim <- st_area(st_polygon(list(cbind(cntr.sim$x, cntr.sim$y))))
      area.surv <- st_area(st_polygon(list(cbind(cntr.surv$x, cntr.surv$y))))
      intsxn <- list(area = list(intsxn = area.intsxn, sim = area.sim, surv = area.surv), sim.kde = sim.kde, surv.kde = surv.kde)
    } else { stop('"method=" must be either "mcp" or "kde"!') }
  }
  return(intsxn)
}    

##  test object:
#require(coda)
#tst.lst <- mcmc.list()
#for (i in 1:3) {
#  require(gtools)
#  tst.lst[[i]] <- {tmp <- rdirichlet(n = 1000, alpha = c(7,10,10)); colnames(tmp) <- c("juv", "sa", "ad"); tmp }
#}  

###  function to get a minumum convex polygon (that one corresponding to the "level" argument)
###  what's returned is the indices of the points (rows) in "mat" that fall on the MCP.
mcp <- function (mat, level) {
  if (ncol(mat) != 2) { stop('mcp: the "mat" object needs to have 2 columns, corresponding to x and y coordinates.') }
  ###  Find the centroid of the (valid) populations (bivariate median).
  cart.med <- drop(apply(mat, MAR = 2, FUN = median))
  
  ###  How many points to remove, before producing minimum convex polygon?
  k <- round((1 - level) * dim(mat)[1])
  
  len <- dim(mat)[1]
  ind <- cbind(rep(1:len, each = len),
               rep(1:len, times = len))
  
  ###  Find distance of each population, from centroid (bivariate median).
  cart.dist.med <- apply(mat, MAR = 1, FUN = dist.fun, v = cart.med)
  
  ###  Remove the k furthest from the centroid (relative distance is preserved, in the conversion from barycentric to Cartesian coordinates).
  cart.cut.med <- mat[order(cart.dist.med, decreasing = T),][-(1:k),]
  
  ###  make the convex polygon:
  mcp.lst <- convhulln(cart.cut.med, options = "Fa")
  
  return(mcp.lst)
}


survProc <- function (surv, tri) {
  require(coda)
  require(MASS)
  require(geometry)
  cl <- class(surv)
  if (!(cl %in% c("mcmc", "mcmc.list", "matrix"))) { stop('Oops: object "surv" must be of class "mcmc", "mcmc.list", or "matrix"!') }
  if (cl == "mcmc.list") {    ## transform to matrix, placing chains end-to-end
    #    surv <- sapply(surv, FUN = as.matrix)  ### no! @$#%
    surv <- do.call("rbind", surv) 
  }
  if (cl == "mcmc") { surv <- as.matrix(surv) }
  
  if (ncol(surv) == 3) {   ## if matrices have 3 columns, must convert to Cartesian coordinates:
    surv <- bary2cart(X = tri, Beta = surv)
  }
  
  if (ncol(surv) != 2) { stop("You goofed: your object is not (or couldn't be converted to) a 2-column matrix representing Cartesian points.") }
  return(surv)
}


###  Plot histogram of accepted populations' fecundity values:
f.hist <- function (sim) {
  x11()
  hist(sim$f, main = "", xlab = expression(italic(f)))
  u <- par("usr")
  text(x = u[1] + 0.2*(u[2]-u[1]), y = u[3] + 0.8*(u[4]-u[3]), labels = bquote(italic(n) == .(length(sim$f)))) 
}


###  Make color vector for populations, corresponding to fecundity.
f.col <- function (sim) {
  out <- list()
  out$ramp <- colorRamp(colors = c("blue", "red"))
  out$pal <- colorRampPalette(colors = c("blue", "red"))
  out$cols <- rgb(out$ramp(sim$f/sim$sim.inputs$max.f), max = 255)
  return(out)
}


###  3d plot of sim pts:
###  on triangle in 3d: provided to help spot problems.
simPlot.3d <- function (sim) {
  require(rgl)
  open3d()
  plot3d(x = as.matrix(sim$bary.pts), xlim = c(-1,1), ylim = c(-1,1), zlim = c(-1,1), col = f.col(sim)$cols, size = 4)
  lines3d(x = rbind(diag(3), diag(3)[1,]), col = "blue")
  for (i in 1:3) {
    lines3d(x = rbind(diag(3)[i,], -diag(3)[i,]), col = "lightgray", lwd = 0.7)
  }
}

################# Run Functions ############


Run.me <- function(q1){
  
  starttime <- Sys.time()
  Transects <- Trans
  nz <- nrow(Burrs)*3
  
  if(Freq == "Enhanced LTDS") {Found1 <- subset(Burrs, Burrs$Found != 1)  ## ISUS
  Found2 <- subset(Burrs, Burrs$Found == 1)}
  
  if((chosenmodel == "111" | chosenmodel == "211" | chosenmodel == "121" |chosenmodel == "221")){
    v2 <- Veg$Veg
    v2 <- ifelse(v2 < 0.05, .05, v2)
    v2 <- ifelse(v2 > 0.95, .95, v2)
    q = length(v2)}
  
  if(Freq == "Conventional LTDS"){    #Conventional LTDS
    x <- c(Burrs$dist, rep(NA,nz))
    y <- c(rep(1,nrow(Burrs)), rep(0,nz))
    z <- c(Burrs$size, rep(NA,nz))
    z <- ifelse(z > 65, 65, z)
    z <- ifelse(z < 4, 4, z)
    o <- c(Burrs$Occ, rep (NA, nz))
    L <- sum(Transects$Length)*10^-4
    v <- c(Burrs$Veg, rep(NA,nz))
    v <- ifelse(v < .05, .05 , ifelse(v > .95, .95, v))
    
    nind = nrow(Burrs)
    Bx = max(Burrs$dist, na.rm = TRUE)
    clust <- rep(NA,(nind +nz)) 	# no idea which cluster anything is in, so unknown	
  }
  
  if(Freq == "Enhanced LTDS"){  #ELTDS
    x <- c(Found1$dist, Found2$dist, rep(NA, nz))
    y <- c(Found1$Found, Found2$Found,rep(0, nz))
    z <- c(Found1$size, Found2$size, rep(NA, nz))
    z <- ifelse(z > 65, 65, z)
    z <- ifelse(z < 4, 4, z)
    o <- c(Found1$Occ,Found2$Occ, rep(NA, nz))
    v <- c(Found1$Veg, Found2$Veg, rep(NA,nz))
    v <- ifelse(v < .05, .05 , ifelse(v > .95, .95, v))
    nind.LT <- nrow(Found2)   ## calling these counts nind.LT and nind.IS to keep things straight
    nind.IS <- nrow(Found1) ## Things in ISU boxes
    Bx <- max(Found2$dist)
    clust = rep(NA, (nind.IS+nind.LT+nz)) 
    L <- sum(Transects$Length)*10^-4
  }
  
  
 Nclust <- 10

  clust[which.min(z)]=1 # smallest value assigned to cluster 1; generally represents juvis


  ### Run the model you want to run - initial values and inputs will change, as will desired outputs

  if(selected.model == "modelstring.PCV" | selected.model == "modelstring.ICV") {#conventional with veg
    jd.test <<- list(nind= nind, nz = nz, L = L, Bx = Bx, x=x,y=y,z=z, Nclust = Nclust, q=q, o=o, v=v,
                  clust= clust, onesRepNclust = rep(1,Nclust),  pmin = p.min, pmax = p.max)
    ji.test1 <<-list(pClust = runif(Nclust, 0.1, 0.9), shape = runif(Nclust, 10, 80),
                     betaClust = runif(Nclust, 0.2, 1.9), sigma.int = .01, sigma.beta = .05,
                     w = c(rep(1, nind), rbinom(nz, 1,.5)))
    ji.test2 <<-list(pClust = runif(Nclust, 0.1, 0.9), shape = runif(Nclust, 10, 80),
                     betaClust = runif(Nclust, 0.2, 1.9), sigma.int = .01, sigma.beta = .05,
                     w = c(rep(1, nind), rbinom(nz, 1,.5)))
    ji.test3 <<-list(pClust = runif(Nclust, 0.1, 0.9), shape = runif(Nclust, 10, 80),
                     betaClust = runif(Nclust, 0.2, 1.9), sigma.int = .02, sigma.beta = .05,
                     w = c(rep(1, nind), rbinom(nz, 1,.5)))}
  if(selected.model == "modelstring.PC" | selected.model == "modelstring.IC") {#conventional no veg
    jd.test <<- list(nind= nind, nz = nz, L = L, Bx = Bx, x=x,y=y,z=z, Nclust = Nclust, o=o,
                    clust= clust, onesRepNclust = rep(1,Nclust),  pmin = p.min, pmax = p.max)
    ji.test1 <<-list(pClust = runif(Nclust, 0.1, 0.9), shape = runif(Nclust, 10, 80),
                     betaClust = runif(Nclust, 0.2, 1.9), sigma.int = .01, sigma.beta = .05,
                     w = c(rep(1, nind), rbinom(nz, 1,.5)))
    ji.test2 <<-list(pClust = runif(Nclust, 0.1, 0.9), shape = runif(Nclust, 10, 80),
                     betaClust = runif(Nclust, 0.2, 1.9), sigma.int = .01, sigma.beta = .05,
                     w = c(rep(1, nind), rbinom(nz, 1,.5)))
    ji.test3 <<-list(pClust = runif(Nclust, 0.1, 0.9), shape = runif(Nclust, 10, 80),
                     betaClust = runif(Nclust, 0.2, 1.9), sigma.int = .02, sigma.beta = .05,
                     w = c(rep(1, nind), rbinom(nz, 1,.5)))}
  if(selected.model == "modelstring.PEV" | selected.model == "modelstring.IEV") {#enhanced with veg
    jd.test <<- list(nind.LT= nind.LT, nz=nz, L = L, x=x,y=y,z=z, o=o, Bx = Bx, Nclust = Nclust,
                 clust= clust, onesRepNclust = rep(1,Nclust), nind.IS= nind.IS, q= q, v= v,  pmin = p.min, pmax = p.max)
    ji.test1 <<-list(pClust = runif(Nclust, 0.1, 0.9), shape = runif(Nclust, 10, 80),
                     betaClust = runif(Nclust, 0.2, 1.9), sigma.int = .01, sigma.beta = .05,
                     w = c(rep(1, nind.IS+nind.LT), rbinom(nz, 1,.5)))
    ji.test2 <<-list(pClust = runif(Nclust, 0.1, 0.9), shape = runif(Nclust, 10, 80),
                     betaClust = runif(Nclust, 0.2, 1.9), sigma.int = .01, sigma.beta = .05,
                     w = c(rep(1, nind.IS+nind.LT), rbinom(nz, 1,.5)))
    ji.test3 <<-list(pClust = runif(Nclust, 0.1, 0.9), shape = runif(Nclust, 10, 80),
                     betaClust = runif(Nclust, 0.2, 1.9), sigma.int = .02, sigma.beta = .05,
                     w = c(rep(1, nind.IS+nind.LT), rbinom(nz, 1,.5)))}
  if(selected.model == "modelstring.PE" | selected.model == "modelstring.IE") {#enhanced no veg
    jd.test <<- list(nind.LT= nind.LT, nz = nz, L = L, Bx = Bx, x=x,y=y,z=z, Nclust = Nclust, o=o,
                 clust= clust, onesRepNclust = rep(1,Nclust), nind.IS= nind.IS, pmin = p.min, pmax = p.max)
    ji.test1 <<-list(pClust = runif(Nclust, 0.1, 0.9), shape = runif(Nclust, 10, 80),
                     betaClust = runif(Nclust, 0.2, 1.9), sigma.int = .01, sigma.beta = .05,
                     w = c(rep(1, nind.IS+nind.LT), rbinom(nz, 1,.5)))
    ji.test2 <<-list(pClust = runif(Nclust, 0.1, 0.9), shape = runif(Nclust, 10, 80),
                     betaClust = runif(Nclust, 0.2, 1.9), sigma.int = .01, sigma.beta = .05,
                     w = c(rep(1, nind.IS+nind.LT), rbinom(nz, 1,.5)))
    ji.test3 <<-list(pClust = runif(Nclust, 0.1, 0.9), shape = runif(Nclust, 10, 80),
                     betaClust = runif(Nclust, 0.2, 1.9), sigma.int = .02, sigma.beta = .05,
                     w = c(rep(1, nind.IS+nind.LT), rbinom(nz, 1,.5)))
    }


  

  jp.test <<- c("D","N",  "sigma.int", "sigma.beta", "big", "small", "med", "Nt","Dt",
                "p.online", "o.int", "Occ",
                "z.beta", "b.point", "juvi1", "juvi2", "juvi3")

  if(selected.model == "modelstring.PEV" | selected.model == "modelstring.IEV" |
     selected.model == "modelstring.PCV" | selected.model == "modelstring.ICV" ){
    jp.test <<- c("D","Dt", "N","Nt",
               "sigma.int", "sigma.beta", "p.online", "b.point", "Occ",
               "o.int", "z.beta", "sigma.gamma", "d", "e", "juvi1", "juvi2", "juvi3")}

  print("Time to actually run the model!")
  Foo <<- suppressWarnings(autorun.jags(eval(parse(text = selected.model)), data = jd.test, inits = list(ji.test1, ji.test2, ji.test3), monitor= jp.test,
                                       startburnin = 4000, startsample = 5000, adapt = 200, method = 'parallel', n.chain = 3, max.time= maxusrtime,
                                       psrf.target = 1.1,silent.jags = FALSE, summarise = TRUE))
  print("Results coming soon!")
  Covmod <- summary(Foo)
  Ext <<- Foo

  results = list()
  results$Site <- paste(selected.model)
  results$LTDS <- Covmod
  results$Time <- paste("Above Results Created:", Sys.time())

  lapply(results, function(x) write.table(data.frame(x), 'results_Bias_Adjusted_LTDS.csv'  ,
                                          append= T, sep=',' ,row.names = T, col.names = NA ))
  
  
  
  beep <- Foo$mcmc
  tst.lst <- beep[[2]][,c("small", "med", "big")]
  dput(beep, "Output_mcmc")
  tst.lst <- window(tst.lst, start=nrow(tst.lst)-700, end=nrow(tst.lst)-200, thin=1)
  Found <- subset(Burrs, Burrs$Tort == 1 & Burrs$Found == 1)
  raw.est <- data.frame(small = sum(Found$size < 13), 
                        med = sum(Found$size < 22 & Found$size >=13), 
                        big = sum(Found$size >= 22))/nrow(Found)
  
  tri <- rbind(rep(0,2), c(1,0), c(0.5,1/(2*tan(pi/6))))
  rownames(tri) <- names(raw.est)
  raw.pt <- bary2cart(X = tri, Beta = as.matrix(raw.est))
  simPlot(sim = simFun(), surv = tst.lst, raw.pt = raw.pt)
  
  shape1 <- gregexpr(pattern ='shape',Foo$end.state[1])[[1]][1]
  shape2 <- gregexpr(pattern ='sigma.beta',Foo$end.state[1])[[1]][1]
  shapes <- as.numeric(unlist(strsplit(substr(Foo$end.state[1], shape1+13, shape2-4), ",")))
  pclust1 <- gregexpr(pattern ='pClust',Foo$end.state[1])[[1]][1]
  pclust2 <- gregexpr(pattern ='psi',Foo$end.state[1])[[1]][1]
  pclusts <- as.numeric(unlist(strsplit(substr(Foo$end.state[1], pclust1+14, pclust2-4), ",")))
  betaclust1 <- gregexpr(pattern ='betaClust',Foo$end.state[1])[[1]][1]
  betaclust2 <- gregexpr(pattern ='c.beta',Foo$end.state[1])[[1]][1]
  betaclusts <- as.numeric(unlist(strsplit(substr(Foo$end.state[1], betaclust1+17, betaclust2-4), ",")))
  
  gammas <- data.frame(shape = shapes, rate = betaclusts, ps = pclusts)
  write.table(gammas, file = "Size_Distribution.csv", sep = ",", append = T, col.names = NA)
  xs <- seq(0,70, by = .01)
  kall <- dgamma(xs, shape = shapes[1], rate = betaclusts[1])*pclusts[1]+
    dgamma(xs, shape = shapes[2], rate = betaclusts[2])*pclusts[2]+
    dgamma(xs, shape = shapes[3], rate = betaclusts[3])*pclusts[3]+
    dgamma(xs, shape = shapes[4], rate = betaclusts[4])*pclusts[4]+
    dgamma(xs, shape = shapes[5], rate = betaclusts[5])*pclusts[5]+
    dgamma(xs, shape = shapes[6], rate = betaclusts[6])*pclusts[6]+
    dgamma(xs, shape = shapes[7], rate = betaclusts[7])*pclusts[7]+
    dgamma(xs, shape = shapes[8], rate = betaclusts[8])*pclusts[8]+
    dgamma(xs, shape = shapes[9], rate = betaclusts[9])*pclusts[9]+
    dgamma(xs, shape = shapes[10], rate = betaclusts[10])*pclusts[10]
  
  # jpeg(filename = "Burrow_Size_Distribution.jpg", width = 10, height = 8, units = "in", type = "windows", res = 300)
  # par(mfrow = c(1,1), mar = c(5,2,3,2))
  # plot(xs, kall, type = "l", main = "Estimated Burrow Size Curve for Population",
  #      col = "black", lwd =2,  cex.lab = 1.5, cex.axis = 1.5, cex.main = 1.5, xlab = "Burrow Width in cm",
  #      ylab = "", yaxt = "n", ylim = c(-.0002, max(kall)+.0005))
  # percents <- Covmod[c("juvi1", "juvi2", "juvi3"), 4]
  # legend("topright", c(paste(round(percents[1],2)*100, "%", "  ", "< 13 cm"), 
  #                      paste(round(percents[2],2)*100, "%", "  ", "13-21 cm"), 
  #                      paste(round(percents[3],2)*100, "%", "  ", "> 21 cm")), 
  #        text.col = c("darkgreen", "purple", "blue"), cex = 1.35)
  # arrows(4, -.0002, 12.9, -.0002, length = 0.075, col = "darkgreen", code = 3, angle = 30, lwd = 2)
  # arrows(13, -.0002, 21.9, -.0002, length = 0.075, col = "purple", code = 3, angle = 30, lwd = 2)
  # arrows(22, -.0002, 65, -.0002, length = 0.075, col = "blue", code = 3, angle = 30, lwd = 2)
  # dev.off()
  
  z.beta <- Covmod["z.beta", 4]
  o.int <- Covmod["o.int",4]
  Occ <<- exp(o.int + z.beta*xs)/(1+exp(o.int + z.beta*xs))
  
  jpeg(filename = "Tortoise_Size_Distribution.jpg", width = 10, height = 8, units = "in", type = "windows", res = 300)
  par(mfrow = c(1,1), mar = c(5,2,3,2))
  plot(xs, kall*Occ, type = "l", main = "Estimated Tortoise Size Curve for Population",
       col = "black", lwd =2,  cex.lab = 1.5, cex.axis = 1.5, cex.main = 1.5, xlab = "Burrow Width in cm",
       ylab = "", yaxt = "n", ylim = c(-.0002, max(kall*Occ)+.0005))
  percents <- Covmod[c("small", "med", "big"), 4]
  legend("topright", c(paste(round(percents[1],2)*100, "%", "  ", "< 13 cm"), 
                       paste(round(percents[2],2)*100, "%", "  ", "13-21 cm"), 
                       paste(round(percents[3],2)*100, "%", "  ", "> 21 cm")), 
         text.col = c("darkgreen", "purple", "blue"), cex = 1.35)
  arrows(4, -.0002, 12.9, -.0002, length = 0.075, col = "darkgreen", code = 3, angle = 30, lwd = 2)
  arrows(13, -.0002, 21.9, -.0002, length = 0.075, col = "purple", code = 3, angle = 30, lwd = 2)
  arrows(22, -.0002, 65, -.0002, length = 0.075, col = "blue", code = 3, angle = 30, lwd = 2)
  dev.off()

  
  return(Foo)
  
  
}


Extend.me <- function(q2){
  try2 <- extract.runjags(Ext, 'end.state')
  Foo <<- suppressWarnings(autorun.jags(eval(parse(text = selected.model)), data = jd.test, inits = try2, monitor= jp.test,
                                       startburnin = 10000, startsample = 8000, adapt = 200, method = 'parallel', n.chain = 3, max.time=maxusrtime,
                                       psrf.target = 1.1,silent.jags = FALSE, summarise = TRUE))
  print("New and improved results coming soon!")
  Covmod <- summary(Foo)
  Ext <<- Foo

  results = list()
  results$Site <- paste(selected.model)
  results$LTDS <- Covmod
  results$Time <- paste("Above Results Created:", Sys.time())


  lapply(results, function(x) write.table(data.frame(x), 'results_Bias_Adjusted_LTDS.csv'  ,
                                          append= T, sep=',' ,row.names = T, col.names = NA ))
  
  beep <- Foo$mcmc
  tst.lst <- beep[[2]][,c("small", "med", "big")]
  dput(beep, "Output_extended_mcmc")
  tst.lst <- window(tst.lst, start=nrow(tst.lst)-500, end=nrow(tst.lst)-200, thin=1)
  Found <- subset(Burrs, Burrs$Tort == 1 & Burrs$Found == 1)
  raw.est <- data.frame(small = sum(Found$size < 13), 
                        med = sum(Found$size < 22 & Found$size >=13), 
                        big = sum(Found$size >= 22))/nrow(Found)
  
  tri <- rbind(rep(0,2), c(1,0), c(0.5,1/(2*tan(pi/6))))
  rownames(tri) <- names(raw.est)
  raw.pt <- bary2cart(X = tri, Beta = as.matrix(raw.est))
  simPlot(sim = simFun(), surv = tst.lst, raw.pt = raw.pt)
  
  shape1 <- gregexpr(pattern ='shape',Foo$end.state[1])[[1]][1]
  shape2 <- gregexpr(pattern ='sigma.beta',Foo$end.state[1])[[1]][1]
  shapes <- as.numeric(unlist(strsplit(substr(Foo$end.state[1], shape1+13, shape2-4), ",")))
  pclust1 <- gregexpr(pattern ='pClust',Foo$end.state[1])[[1]][1]
  pclust2 <- gregexpr(pattern ='psi',Foo$end.state[1])[[1]][1]
  pclusts <- as.numeric(unlist(strsplit(substr(Foo$end.state[1], pclust1+14, pclust2-4), ",")))
  betaclust1 <- gregexpr(pattern ='betaClust',Foo$end.state[1])[[1]][1]
  betaclust2 <- gregexpr(pattern ='c.beta',Foo$end.state[1])[[1]][1]
  betaclusts <- as.numeric(unlist(strsplit(substr(Foo$end.state[1], betaclust1+17, betaclust2-4), ",")))
  
  gammas <- data.frame(shape = shapes, rate = betaclusts, ps = pclusts)
  write.table(gammas, file = "Size_Distribution.csv", sep = ",", append = T, col.names = NA)
  xs <- seq(0,70, by = .01)
  kall <- dgamma(xs, shape = shapes[1], rate = betaclusts[1])*pclusts[1]+
    dgamma(xs, shape = shapes[2], rate = betaclusts[2])*pclusts[2]+
    dgamma(xs, shape = shapes[3], rate = betaclusts[3])*pclusts[3]+
    dgamma(xs, shape = shapes[4], rate = betaclusts[4])*pclusts[4]+
    dgamma(xs, shape = shapes[5], rate = betaclusts[5])*pclusts[5]+
    dgamma(xs, shape = shapes[6], rate = betaclusts[6])*pclusts[6]+
    dgamma(xs, shape = shapes[7], rate = betaclusts[7])*pclusts[7]+
    dgamma(xs, shape = shapes[8], rate = betaclusts[8])*pclusts[8]+
    dgamma(xs, shape = shapes[9], rate = betaclusts[9])*pclusts[9]+
    dgamma(xs, shape = shapes[10], rate = betaclusts[10])*pclusts[10]
  
  # jpeg(filename = "Burrow_Size_Distribution.jpg", width = 10, height = 8, units = "in", type = "windows", res = 300)
  # par(mfrow = c(1,1), mar = c(5,2,3,2))
  #      plot(xs, kall, type = "l", main = "Estimated Burrow Size Curve for Population",
  #           col = "black", lwd =2,  cex.lab = 1.5, cex.axis = 1.5, cex.main = 1.5, xlab = "Burrow Width in cm",
  #           ylab = "", yaxt = "n", ylim = c(-.0002, max(Kall)+.0005))
  #      percents <- Covmod[c("juvi1", "juvi2", "juvi3"), 4]
  #      legend("topright", c(paste(round(percents[1],2)*100, "%", "  ", "< 13 cm"), 
  #                           paste(round(percents[2],2)*100, "%", "  ", "13-21 cm"), 
  #                           paste(round(percents[3],2)*100, "%", "  ", "> 21 cm")), 
  #                           text.col = c("darkgreen", "purple", "blue"), cex = 1.35)
  #      arrows(4, -.0002, 12.9, -.0002, length = 0.075, col = "darkgreen", code = 3, angle = 30, lwd = 2)
  #      arrows(13, -.0002, 21.9, -.0002, length = 0.075, col = "purple", code = 3, angle = 30, lwd = 2)
  #      arrows(22, -.0002, 65, -.0002, length = 0.075, col = "blue", code = 3, angle = 30, lwd = 2)
  # dev.off()
  # 
  z.beta <- Covmod["z.beta", 4]
  o.int <- Covmod["o.int",4]
  Occ <<- exp(o.int + z.beta*xs)/(1+exp(o.int + z.beta*xs))
  
  jpeg(filename = "Tortoise_Size_Distribution.jpg", width = 10, height = 8, units = "in", type = "windows", res = 300)
  par(mfrow = c(1,1), mar = c(5,2,3,2))
  plot(xs, kall*Occ, type = "l", main = "Estimated Tortoise Size Curve for Population",
       col = "black", lwd =2,  cex.lab = 1.5, cex.axis = 1.5, cex.main = 1.5, xlab = "Burrow Width in cm",
       ylab = "", yaxt = "n", ylim = c(-.0002, max(Kall*Occ)+.0005))
  percents <- Covmod[c("small", "med", "big"), 4]
  legend("topright", c(paste(round(percents[1],2)*100, "%", "  ", "< 13 cm"), 
                       paste(round(percents[2],2)*100, "%", "  ", "13-21 cm"), 
                       paste(round(percents[3],2)*100, "%", "  ", "> 21 cm")), 
         text.col = c("darkgreen", "purple", "blue"), cex = 1.35)
  arrows(4, -.0002, 12.9, -.0002, length = 0.075, col = "darkgreen", code = 3, angle = 30, lwd = 2)
  arrows(13, -.0002, 21.9, -.0002, length = 0.075, col = "purple", code = 3, angle = 30, lwd = 2)
  arrows(22, -.0002, 65, -.0002, length = 0.075, col = "blue", code = 3, angle = 30, lwd = 2)
  dev.off()
  
  
}

